To run this game, double click on Project2.exe. 
Enjoy! :) 


--Diana Ly, William Chiang, Colin Clayton 

