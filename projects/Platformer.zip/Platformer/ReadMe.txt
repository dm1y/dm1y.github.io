To run this game, please double click on Project2.exe. 

If it doesn't run, please make sure you have extracted all the files from this .zip

Thank you and enjoy our game! :)

--Diana Ly, William Chiang, Colin Clayton  

